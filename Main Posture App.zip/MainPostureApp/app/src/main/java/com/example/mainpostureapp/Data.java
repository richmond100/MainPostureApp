package com.example.mainpostureapp;


public class Data
{
    private String thisDate;
    private int bottomL;
    private int bottomR;
    private int topL;
    private int topR;
    private int slouch;

    public Data(int[] errorArray, String date)
    {
        bottomL = errorArray[0];
        bottomR = errorArray[1];
        topL = errorArray[2];
        topR = errorArray[3];
        slouch = errorArray[4];
        thisDate = date;
    }

    public Data update(Data other)
    {
        bottomL += other.getBottomL();
        bottomR += other.getBottomR();
        topL += other.getTopL();
        topR += other.getTopR();
        slouch += other.getSlouch();
        int [] a = {bottomL, bottomR, topL,topR, slouch};
        Data s = new Data(a,thisDate);
        return s;
    }
    public String toString()
    {
        StringBuilder str = new StringBuilder();
        str.append(thisDate + "   ");
        str.append(topL + "   ");
        str.append(topR + "   ");
        str.append(bottomL + "   ");
        str.append(bottomR + "   ");
        str.append(slouch);
        return str.toString();

    }

    public int getBottomL()
    {
        return bottomL;
    }

    public int getBottomR()
    {
        return bottomR;
    }

    public int getTopL()
    {
        return topL;
    }

    public int getTopR()
    {
        return topR;
    }
    public int getSlouch()
    {
        return slouch;
    }

    public String getDate()
    {
        return thisDate;
    }
}

